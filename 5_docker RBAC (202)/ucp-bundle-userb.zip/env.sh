export DOCKER_TLS_VERIFY=1
export DOCKER_CERT_PATH="$(pwd)"
export DOCKER_HOST=tcp://10.12.20.81:443
#
# Bundle for user userb
# UCP Instance ID HVQC:P2I7:LPWD:JAJA:BKG2:A2LQ:5G6E:3BLD:UEC7:TN23:MLTW:PAS6
#
# Run this command from within this directory to configure your shell:
# eval $(<env.sh)
