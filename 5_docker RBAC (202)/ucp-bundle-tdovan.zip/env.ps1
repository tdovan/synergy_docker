$Env:DOCKER_TLS_VERIFY = "1"
$Env:DOCKER_CERT_PATH = $(Split-Path $script:MyInvocation.MyCommand.Path)
$Env:DOCKER_HOST = "tcp://10.12.20.81:443"
#
# Bundle for user tdovan
# UCP Instance ID HVQC:P2I7:LPWD:JAJA:BKG2:A2LQ:5G6E:3BLD:UEC7:TN23:MLTW:PAS6
#
# This admin cert will also work directly against Swarm and the individual
# engine proxies for troubleshooting.  After sourcing this env file, use
# "docker info" to discover the location of Swarm managers and engines.
# and use the --host option to override $DOCKER_HOST
#
# Run this command from within this directory to configure your shell:
# Import-Module .\env.ps1
